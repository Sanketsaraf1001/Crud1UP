﻿using System.Collections.Generic;
using CRUD1.Models;
using CRUD1.ViewModels;


namespace CRUD1.ViewModels
{
    public class ProductListViewModel
    {
        public List<Product> Products { get; set; }
        public int CurrentPage { get; set; }
        public int TotalPages { get; set; }
    }
}
