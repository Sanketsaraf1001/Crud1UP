﻿using CRUD1.Models;
using CRUD1.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace CRUD1.Controllers
{
    public class ProductController : Controller
    {
        private const int PageSize = 10; // Number of products per page

        private readonly ProductService _productService;

        public ProductController(ProductService productService)
        {
            _productService = productService;
        }

        public async Task<IActionResult> Index(int page = 1)
        {
            var products = await _productService.GetAllProductsAsync();

            // Calculate total number of pages
            var totalPages = (int)Math.Ceiling(products.Count() / (double)PageSize);

            // Adjust page value if it exceeds the total number of pages
            if (page < 1)
            {
                page = 1;
            }
            else if (page > totalPages)
            {
                page = totalPages;
            }

            // Apply pagination
            var pagedProducts = products
                .Skip((page - 1) * PageSize)
                .Take(PageSize)
                .ToList();

            // Create a view model with pagination details
            var viewModel = new ProductListViewModel
            {
                Products = pagedProducts,
                CurrentPage = page,
                TotalPages = totalPages
            };

            return View(viewModel); // Pass the viewModel as the model to the view
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Product product)
        {
            if (ModelState.IsValid)
            {
                // Assign the selected category's CategoryId to the product's CategoryId property
                product.CategoryId = Convert.ToInt32(Request.Form["CategoryId"]);

                await _productService.CreateProductAsync(product);
                return RedirectToAction(nameof(Index));
            }

            return View(product);
        }

        public async Task<IActionResult> Edit(int id)
        {
            var product = await _productService.GetProductByIdAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(Product product)
        {
            if (ModelState.IsValid)
            {
                await _productService.UpdateProductAsync(product);
                return RedirectToAction(nameof(Index));
            }

            return View(product);
        }

        public async Task<IActionResult> Delete(int id)
        {
            var product = await _productService.GetProductByIdAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        [HttpPost]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _productService.DeleteProductAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
